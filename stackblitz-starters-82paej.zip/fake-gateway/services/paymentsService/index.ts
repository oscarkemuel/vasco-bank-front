import { Router } from 'express';

const paymentsService = Router();

export { paymentsService }