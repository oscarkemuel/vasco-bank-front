export const APP_ROUTES = {
  private: {
    dashboard: {
      home: '/dashboard',
    }
  },
  public: {
    home: '/',
    login: '/login',
    register: '/register',
  }
}